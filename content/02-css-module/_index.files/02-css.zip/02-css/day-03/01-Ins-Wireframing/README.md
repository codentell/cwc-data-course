# Create a Wireframe (Instructor)

The following image shows the start of a wireframe for the mini-project for this unit:

![Example of an unfinished wireframe with its row and columns highlighted.](./assets/images/01-unfinished-wireframe.png)

* The areas outlined in red represent rows.

* The areas outlined in blue represent columns.

---
© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.