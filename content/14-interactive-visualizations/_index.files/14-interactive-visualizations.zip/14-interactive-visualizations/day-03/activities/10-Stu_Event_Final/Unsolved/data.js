let data = {
    australia: {
        "Domestic Health": 84241,
        "Education": 68160,
        "Final Consumption": 247409,
        "Research and Development": 24918
    },

    brazil: {
        "Domestic Health": 81832,
        "Education": 130424,
        "Final Consumption": 416043,
        "Research and Development": 22573
    },

    uk: {
        "Domestic Health": 207917,
        "Education": 144950,
        "Final Consumption": 498433,
        "Research and Development": 44736
    },

    mexico: {
        "Domestic Health": 32947,
        "Education": 52362,
        "Final Consumption": 134626,
        "Research and Development": 3806
    },

    singapore: {
        "Domestic Health": 7312,
        "Education": 9504,
        "Final Consumption": 34940,
        "Research and Development": 6608
    },

    southAfrica: {
        "Domestic Health": 15215,
        "Education": 21368,
        "Final Consumption": 72704,
        "Research and Development": 2909
    }
};
