// The new student and grade to add to the table
let newGrade = ["Wash", 79];

// Use D3 to select the table

// Use d3 to create a bootstrap striped table
// http://getbootstrap.com/docs/3.3/css/#tables-striped

// Use D3 to select the table body

// Append one table row `tr` to the table body

// Append one cell for the student name

// Append one cell for the student grade
