// Get the Roadster endpoint


// Fetch the JSON data and console log it


// Get the capsules endpoint


// Fetch the JSON data and console log it