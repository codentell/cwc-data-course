let movies = [
    {
        title: 'Gone with the Wind',
        profit: 3739000000,
        year: 1939
    },
    {
        title: 'Avatar',
        profit: 3286000000,
        year: 2009
    },
    {
        title: 'Titanic',
        profit: 3108000000,
        year: 1997
    },
    {
        title: 'Star Wars',
        profit: 3071000000,
        year: 1977
    },
    {
        title: 'Avengers: Endgame',
        profit: 2823000000,
        year: 2019
    },
    {
        title: "The Sound of Music",
        profit: 2572000000,
        year: 1965
    },
    {
        title: 'E.T. the Extra-Terrestrial',
        profit: 2511000000,
        year: 1982
    },
    {
        title: 'The Ten Commandments',
        profit: 2377000000,
        year: 1956
    },
    {
        title: 'Doctor Zhivago',
        profit: 2253000000,
        year: 1965
    },
    {
        title: 'Star Wars: The Force Awakens',
        profit: 2221000000,
        year: 2015
    }
]