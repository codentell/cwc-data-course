// Prototypical use case increments loop counter by one on each iteration
for (let i = 0; i < 10; i++) {
  console.log("Iteration #", i);
}

// Looping through an array
let students = ["Johnny", "Tyler", "Bodhi", "Pappas"];

for (let j = 0; j < students.length; j++) {
  console.log(students[j]);
}
