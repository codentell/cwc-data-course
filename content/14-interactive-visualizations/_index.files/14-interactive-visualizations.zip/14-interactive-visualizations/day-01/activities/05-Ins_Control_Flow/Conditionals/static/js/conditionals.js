let painAfterInjury = true;
let significantSwelling = true;
let ableToWalk = true;
// let painInBothAnkles = true;
// let fever = true;
// let moreThanOneJointSwollenAndRed = true;
// let suddenPain = true;
// let clothingAgainstJoinCausesPain = true;
// let painDuringWeather = true;
// let painAfterUseOfAnkle = true;

if (painAfterInjury && significantSwelling) {
  if (!ableToWalk) {
    console.log("You may have a fracture or sprain.")
    console.log("Don't walk on the injured foot. Raise the leg and place ice on the swollen area.")
    console.log("See your doctor promptly")
  } else {
    console.log("You may have a sprained ankle, or a fracture of the fibula.")
    console.log("Use ice, elevation, rest and an elastic bandage to keep the swelling under control.")
    console.log("See your doctor if the swelling and pain continue.")
  }
} else {
    if (painInBothAnkles) {
      console.log("You may have rheumatoid arthritis")
      console.log("See your doctor. He or she can prescribe medicine to help control the symptoms of rheumatoid arthritis.")
    } else if (fever || moreThanOneJointSwollenAndRed) {
      console.log("Fever along with a painful, swollen joint could be caused by an infected joint. More than one affected joint could mean rheumatic fever.")
      console.log("URGENT. SEE YOUR DOCTOR RIGHT AWAY.")
    } else if (suddenPain || clothingAgainstJoinCausesPain) {
      console.log("You may have gout.")
      console.log("See your doctor. During a gout attack, you should rest in bed. You can put a hot pad or an ice pack on your ankle to ease the pain")
    } else if (painDuringWeather || painAfterUseOfAnkle) {
      console.log("These symptoms could be caused by osteoarthritis or by previous trauma to the ankle.")
      console.log("See your doctor. Use heat and anti-inflammatory medicine to relieve discomfort.")
    } else {
      console.log("For more information, please talk to your doctor. If you think your problem is serious, call right away.")
    }
}