let ratings = ['G', 'PG', 'PG-13', 'R']

// Create a function to calculate the average of a metric by rating


// Invoke the metric average function


// Create a function to plot the average metric by rating results


// Invoke the plot creating function
