console.log(searchResults);

// Initialized arrays
let names = []
let greekNames = []
let romanNames = []
let greekSearchResults = []
let romanSearchResults = []

// YOUR CODE HERE
// For loop to populate arrays


// Trace1 for the Greek Data


// Trace 2 for the Roman Data


// Create data array


// Apply a title to the layout


// Render the plot to the div tag with id "plot"
