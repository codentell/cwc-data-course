# My First HTML Page

Time to put these new skills to the test! In this activity, you'll create a new HTML page from scratch.

## Instructions

  1. Create a new HTML document called `FirstHTML.html`.  
   
  2. Give your HTML page the title "My First HTML Page." 
   
  3. Add some text so that your HTML page renders the words "Woohoo! I just created my first web page!" to the browser.

### Bonus

Feeling fancy? Add a line break and another sentence saying, "Hello, world!"

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.