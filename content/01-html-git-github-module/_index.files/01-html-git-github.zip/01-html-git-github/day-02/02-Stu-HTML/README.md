# Basic Bio

## Instructions:

Using what you've learned of HTML so far complete the following:

* Create a basic HTML page with your own information that looks similar to the design below.

  ![Make it look like this](demo.png)

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
