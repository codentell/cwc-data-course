# Routes with Variable Rules

In this activity, you will add an API route that returns a JSON of a Python dictionary containing an individual superhero’s information.

## Instructions

Using the previous activity as a starting point, add code to get a specific hero's information based on their superhero name.

---

© 2022 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
