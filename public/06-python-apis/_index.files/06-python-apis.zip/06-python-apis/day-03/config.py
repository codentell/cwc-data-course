# Geoapify API Key
geoapify_key = "fe54b47f7c6749be89776313f2bab541"
census_api_key = "22e563afb970b2dfa1d5d607e97fc3b1c74b79fc"
