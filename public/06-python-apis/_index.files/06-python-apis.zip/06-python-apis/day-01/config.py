#  Add your API key
omdb_api_key = "b8debd85"
nyt_api_key="fpgNJQMMAf0Lpw0QKSb0hMdtcxUnMHim"
