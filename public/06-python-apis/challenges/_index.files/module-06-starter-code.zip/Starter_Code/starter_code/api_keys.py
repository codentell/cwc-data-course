# OpenWeatherMap API Key
weather_api_key = "YOUR KEY HERE"

# Geoapify API Key
geoapify_key = "YOUR KEY HERE"
